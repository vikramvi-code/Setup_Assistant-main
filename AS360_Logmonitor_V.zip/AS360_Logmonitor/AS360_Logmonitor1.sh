#!/bin/bash

# Namespaces extracted from the provided screenshot
TARGET_NAMESPACES=(
    "cert-manager"
    "hcl-appscan-ascp"
    "hcl-appscan-asra"
    "hcl-appscan-dast"
    "hcl-appscan-sca"
    "istio-system"
    "kube-system"
)

TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
BASE_DIR="AppScan360_MultiLog_${TIMESTAMP}"

mkdir -p "$BASE_DIR"

echo "========================================================="
echo " AppScan 360 Continuous Multi-Namespace Log Collection"
echo "========================================================="
echo "Output Directory: $BASE_DIR"
echo "Press Ctrl+C to stop"
echo "========================================================="

PIDS=()

cleanup() {
    echo ""
    echo "Stopping log collection..."

    for PID in "${PIDS[@]}"; do
        kill "$PID" 2>/dev/null
    done

    echo "Log collection stopped."
    echo "Logs available in: $BASE_DIR"
    exit 0
}

trap cleanup INT TERM

# ------------------------------------------------
# Validate and Setup Namespaces
# ------------------------------------------------
ACTIVE_NAMESPACES=()

for NS in "${TARGET_NAMESPACES[@]}"; do
    if ! kubectl get namespace "$NS" >/dev/null 2>&1; then
        echo "SKIPPING: Namespace '$NS' does not exist in this cluster."
    else
        echo "MONITORING: Namespace '$NS'"
        ACTIVE_NAMESPACES+=("$NS")
        
        # Create dedicated log folder for the namespace
        mkdir -p "$BASE_DIR/$NS/logs"
        
        # Start continuous event collection for this namespace
        kubectl get events \
            -n "$NS" \
            --watch \
            --output=wide \
            > "$BASE_DIR/$NS/events.log" 2>&1 &
            
        PIDS+=($!)
    fi
done

if [ ${#ACTIVE_NAMESPACES[@]} -eq 0 ]; then
    echo "ERROR: None of the target namespaces exist in the cluster. Exiting."
    exit 1
fi

# ------------------------------------------------
# Function to collect logs for a pod
# ------------------------------------------------
collect_pod_logs() {
    local NS="$1"
    local POD="$2"
    local LOG_FILE="$BASE_DIR/$NS/logs/${POD}.log"

    if [ -f "$LOG_FILE" ]; then
        return
    fi

    echo "Starting log collection for: $NS / $POD"

    (
        echo "=============================================="
        echo "Pod: $POD"
        echo "Namespace: $NS"
        echo "Started: $(date)"
        echo "=============================================="
        echo ""

        kubectl logs "$POD" \
            -n "$NS" \
            --all-containers=true \
            --timestamps=true \
            -f
    ) >> "$LOG_FILE" 2>&1 &

    PIDS+=($!)
}

# ------------------------------------------------
# Continuously detect pods across active namespaces
# ------------------------------------------------
echo "Starting continuous pod tracking..."

while true
do
    for NS in "${ACTIVE_NAMESPACES[@]}"; do
        kubectl get pods \
            -n "$NS" \
            --no-headers 2>/dev/null |
        awk '{print $1}' |
        while read -r POD
        do
            [ -z "$POD" ] && continue

            if [ ! -f "$BASE_DIR/$NS/logs/${POD}.log" ]; then
                collect_pod_logs "$NS" "$POD"
            fi
        done
    done

    sleep 5
done