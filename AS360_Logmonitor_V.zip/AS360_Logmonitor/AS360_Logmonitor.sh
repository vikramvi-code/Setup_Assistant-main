#!/bin/bash

NAMESPACE="$1"

if [ -z "$NAMESPACE" ]; then
    echo "Usage: $0 <namespace>"
    echo "Example: $0 hcl-appscan-sca"
    exit 1
fi

if ! kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
    echo "ERROR: Namespace '$NAMESPACE' does not exist."
    exit 1
fi

TIMESTAMP=$(date '+%Y%m%d_%H%M%S')
BASE_DIR="AppScan360_${NAMESPACE}_${TIMESTAMP}"

mkdir -p "$BASE_DIR/logs"

echo "=============================================="
echo " AppScan 360 Continuous Log Collection"
echo "=============================================="
echo "Namespace : $NAMESPACE"
echo "Output    : $BASE_DIR"
echo "Press Ctrl+C to stop"
echo "=============================================="

PIDS=()

cleanup() {
    echo ""
    echo "Stopping log collection..."

    for PID in "${PIDS[@]}"; do
        kill "$PID" 2>/dev/null
    done

    echo "Log collection stopped."
    echo "Logs available in: $BASE_DIR"
    exit 0
}

trap cleanup INT TERM

# ------------------------------------------------
# Continuous Kubernetes Events
# ------------------------------------------------
echo "Starting continuous event collection..."

kubectl get events \
    -n "$NAMESPACE" \
    --watch \
    --output=wide \
    > "$BASE_DIR/events.log" 2>&1 &

PIDS+=($!)

# ------------------------------------------------
# Function to collect logs for a pod
# ------------------------------------------------
collect_pod_logs() {

    POD="$1"

    LOG_FILE="$BASE_DIR/logs/${POD}.log"

    if [ -f "$LOG_FILE" ]; then
        return
    fi

    echo "Starting log collection for: $POD"

    (
        echo "=============================================="
        echo "Pod: $POD"
        echo "Namespace: $NAMESPACE"
        echo "Started: $(date)"
        echo "=============================================="
        echo ""

        kubectl logs "$POD" \
            -n "$NAMESPACE" \
            --all-containers=true \
            --timestamps=true \
            -f
    ) >> "$LOG_FILE" 2>&1 &

    PIDS+=($!)
}

# ------------------------------------------------
# Continuously detect pods
# ------------------------------------------------
while true
do

    kubectl get pods \
        -n "$NAMESPACE" \
        --no-headers 2>/dev/null |
    awk '{print $1}' |
    while read -r POD
    do
        [ -z "$POD" ] && continue

        if [ ! -f "$BASE_DIR/logs/${POD}.log" ]; then
            collect_pod_logs "$POD"
        fi
    done

    sleep 5

done
